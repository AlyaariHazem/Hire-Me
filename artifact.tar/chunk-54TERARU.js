var n={production:!1,apiBaseUrl:"https://job-portal-rcxk.onrender.com",getUrl:(r,t="accounts")=>n.apiBaseUrl+"/api/"+t+"/"+r+"/"};export{n as a};
