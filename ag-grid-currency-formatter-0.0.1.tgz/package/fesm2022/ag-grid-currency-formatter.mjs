import * as i0 from '@angular/core';
import { Injectable, HostListener, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import * as i2 from '@angular/router';
import * as i3 from 'primeng/overlaypanel';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import * as i4 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import * as i5 from 'primeng/listbox';
import { ListboxModule } from 'primeng/listbox';
import * as i6 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i7 from 'primeng/button';
import { ButtonModule } from 'primeng/button';

class CurrencyService {
    CURR_CODE_KEY = 'selectedCurrencyCode';
    CURR_LOCALE_KEY = 'selectedCurrencyLocale';
    // Special "no currency" option
    NONE = { code: null, locale: null, label: '— None —' };
    // Available currencies (put NONE first so it's the default)
    currencies = [
        this.NONE,
        { code: 'USD', locale: 'en-US', label: 'USD — US Dollar' },
        { code: 'EUR', locale: 'de-DE', label: 'EUR — Euro' },
        { code: 'GBP', locale: 'en-GB', label: 'GBP — British Pound' },
        { code: 'SAR', locale: 'ar-SA', label: 'SAR — Saudi Riyal' },
    ];
    _currency = this.readCurrencyFromLS();
    // ---- Public API ----
    getCurrency() { return this._currency; }
    getCurrencyCode() { return this._currency.code; }
    getCurrencyLocale() { return this._currency.locale; }
    isNone() { return this._currency.code == null; }
    /** Accepts a CurrencyOption, a code string, or null to clear. */
    setCurrency(opt) {
        let chosen;
        if (opt === null) {
            this._currency = this.NONE;
            this.removeFromLS();
            return;
        }
        if (typeof opt === 'string') {
            chosen = this.currencies.find(c => c.code === opt);
        }
        else if (opt && typeof opt === 'object') {
            chosen = this.currencies.find(c => c.code === opt.code);
        }
        this._currency = chosen ?? this.NONE;
        // Persist only when a real currency is selected
        try {
            if (this._currency.code) {
                localStorage.setItem(this.CURR_CODE_KEY, this._currency.code);
                localStorage.setItem(this.CURR_LOCALE_KEY, this._currency.locale ?? '');
            }
            else {
                this.removeFromLS();
            }
        }
        catch { /* ignore storage errors */ }
    }
    // ---- Internal ----
    readCurrencyFromLS() {
        try {
            const code = localStorage.getItem(this.CURR_CODE_KEY);
            const locale = localStorage.getItem(this.CURR_LOCALE_KEY);
            if (!code)
                return this.NONE;
            // If stored code exists, return the configured option or reconstruct a label
            return (this.currencies.find(c => c.code === code) ??
                { code, locale: locale || 'en-US', label: code });
        }
        catch {
            return this.NONE;
        }
    }
    removeFromLS() {
        try {
            localStorage.removeItem(this.CURR_CODE_KEY);
            localStorage.removeItem(this.CURR_LOCALE_KEY);
        }
        catch { /* ignore */ }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CurrencyService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CurrencyService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CurrencyService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

// currency-cell-renderer.component.ts
const CURR_CODE_KEY = 'selectedCurrencyCode';
const CURR_LOCALE_KEY = 'selectedCurrencyLocale';
const DEFAULT_CODE = 'SAR';
const DEFAULT_LOCALE = 'ar-SA';
const CURRENCY_EVT$1 = 'currency-format-changed';
// ⬇️ Use English/Latin digits whenever code is null
const DECIMAL_LOCALE_WHEN_NULL = 'en-US';
class CurrencyCellRendererComponent {
    cdr;
    params;
    value;
    html = '';
    code = DEFAULT_CODE; // may be null
    locale = DEFAULT_LOCALE; // never pass null to Intl
    minFrac = 0;
    maxFrac = 2;
    useGrouping = true;
    constructor(cdr) {
        this.cdr = cdr;
    }
    agInit(params) {
        this.params = params;
        this.value = params.value;
        this.resolveOptions();
        this.render();
    }
    refresh(params) {
        this.params = params;
        this.value = params.value;
        this.resolveOptions();
        this.render();
        return true;
    }
    onStorageChanged(ev) {
        if (ev.key === CURR_CODE_KEY || ev.key === CURR_LOCALE_KEY) {
            this.resolveOptions();
            this.render();
        }
    }
    onCurrencyEvent() {
        this.resolveOptions();
        this.render();
    }
    // -------------------------------
    render() {
        if (this.value == null || this.value === '') {
            this.html = '';
            return this.invalidate();
        }
        const n = typeof this.value === 'number'
            ? this.value
            : Number(String(this.value).replace(/[^\d.-]/g, ''));
        if (!Number.isFinite(n)) {
            this.html = String(this.value);
            return this.invalidate();
        }
        const loc = this.locale ?? undefined;
        // ❗ No currency selected → ALWAYS show English digits (en-US)
        if (!this.code) {
            this.html = new Intl.NumberFormat(DECIMAL_LOCALE_WHEN_NULL, {
                style: 'decimal',
                useGrouping: this.useGrouping,
                minimumFractionDigits: this.minFrac,
                maximumFractionDigits: this.maxFrac,
            }).format(n);
            return this.invalidate();
        }
        // SAR → show Saudi Riyal glyph from the font (not "ر س")
        if (this.code === 'SAR') {
            const num = new Intl.NumberFormat(loc, {
                style: 'decimal',
                useGrouping: this.useGrouping,
                minimumFractionDigits: this.minFrac,
                maximumFractionDigits: this.maxFrac,
            }).format(n);
            this.html =
                `<span class="sar-cell"><span class="icon-saudi_riyal" aria-hidden="true"></span>&nbsp;${num}</span>`;
            return this.invalidate();
        }
        // Other currencies → normal currency formatting in chosen locale
        this.html = new Intl.NumberFormat(loc, {
            style: 'currency',
            currency: this.code,
            useGrouping: this.useGrouping,
            minimumFractionDigits: this.minFrac,
            maximumFractionDigits: this.maxFrac,
        }).format(n);
        this.invalidate();
    }
    resolveOptions() {
        const p = (this.params?.colDef?.cellRendererParams) || {};
        const row = this.params?.data ?? {};
        let codeMaybe = p.currencyCode;
        if (codeMaybe === undefined && p.currencyField)
            codeMaybe = row[p.currencyField];
        if (codeMaybe === undefined)
            codeMaybe = this.readCodeFromLS(); // string | null
        this.code = (codeMaybe === undefined) ? DEFAULT_CODE : codeMaybe; // keep null if explicitly set
        let localeMaybe = p.locale;
        if (localeMaybe === undefined && p.localeField)
            localeMaybe = row[p.localeField];
        if (localeMaybe === undefined)
            localeMaybe = this.readLocaleFromLS();
        this.locale = localeMaybe ?? DEFAULT_LOCALE; // never null to Intl
        this.minFrac = this.pickNum(p.minFractionDigits, 0);
        this.maxFrac = this.pickNum(p.maxFractionDigits, 2);
        this.useGrouping = p.useGrouping !== false;
    }
    readCodeFromLS() {
        try {
            const v = window.localStorage?.getItem(CURR_CODE_KEY);
            return v === null || v === '' ? null : v;
        }
        catch {
            return null;
        }
    }
    readLocaleFromLS() {
        try {
            const v = window.localStorage?.getItem(CURR_LOCALE_KEY);
            return v === null || v === '' ? undefined : v;
        }
        catch {
            return undefined;
        }
    }
    pickNum(v, fb) {
        const n = Number(v);
        return Number.isFinite(n) ? n : fb;
    }
    invalidate() {
        try {
            this.cdr.markForCheck();
            this.cdr.detectChanges();
        }
        catch { }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CurrencyCellRendererComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CurrencyCellRendererComponent, isStandalone: true, selector: "app-currency-cell", host: { listeners: { "window:storage": "onStorageChanged($event)", "window:currency-format-changed": "onCurrencyEvent()" } }, ngImport: i0, template: `<span [innerHTML]="html"></span>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CurrencyCellRendererComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'app-currency-cell',
                    standalone: true,
                    template: `<span [innerHTML]="html"></span>`,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { onStorageChanged: [{
                type: HostListener,
                args: ['window:storage', ['$event']]
            }], onCurrencyEvent: [{
                type: HostListener,
                args: [`window:${CURRENCY_EVT$1}`]
            }] } });

const CURRENCY_EVT = 'currency-format-changed';
class CurrencyComponent {
    settings;
    router;
    // Currency state only
    currencyOptions = [];
    selectedCurrency;
    /** bind with [innerHTML] in the template */
    currencyPreview = '';
    applyCurrencyDisabled = true;
    constructor(settings, router) {
        this.settings = settings;
        this.router = router;
    }
    ngOnInit() {
        this.currencyOptions = this.settings.currencies;
        this.selectedCurrency = this.settings.getCurrency(); // { code, locale, label }
        this.updateCurrencyPreview();
    }
    onCurrencyChange() {
        if (!this.selectedCurrency)
            return;
        this.settings.setCurrency(this.selectedCurrency); // persist to LS
        this.updateCurrencyPreview();
        this.applyCurrencyDisabled = false;
    }
    onApplyCurrency() {
        // ensure persisted
        this.settings.setCurrency(this.selectedCurrency);
        // notify same-tab listeners (inputs/renderers)
        window.dispatchEvent(new CustomEvent(CURRENCY_EVT, {
            detail: { code: this.selectedCurrency.code, locale: this.selectedCurrency.locale }
        }));
        // optional: force re-render like before
        const currentUrl = this.router.url;
        this.router.navigateByUrl('/', { skipLocationChange: true })
            .then(() => this.router.navigate([currentUrl]));
        this.applyCurrencyDisabled = true;
        this.updateCurrencyPreview();
    }
    updateCurrencyPreview() {
        const cur = this.selectedCurrency ?? { code: 'SAR', locale: 'ar-SA', label: '' };
        // Intl.NumberFormat accepts string | string[] | undefined (NOT null)
        const loc = cur.locale ?? undefined;
        // No currency selected -> plain number
        if (!cur.code) {
            this.currencyPreview = new Intl.NumberFormat(loc, {
                style: 'decimal',
                minimumFractionDigits: 2,
            }).format(1234.56);
            return;
        }
        // SAR: render special glyph + decimal number
        if (cur.code === 'SAR') {
            const num = new Intl.NumberFormat(loc, {
                style: 'decimal',
                minimumFractionDigits: 2,
            }).format(1234.56);
            this.currencyPreview =
                `<span class="sar-cell"><span class="icon-saudi_riyal"></span>&nbsp;${num}</span>`;
            return;
        }
        // Any other currency
        this.currencyPreview = new Intl.NumberFormat(loc, {
            style: 'currency',
            currency: cur.code, // cur.code is string here
        }).format(1234.56);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CurrencyComponent, deps: [{ token: CurrencyService }, { token: i2.Router }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.3", type: CurrencyComponent, isStandalone: false, selector: "app-currency", ngImport: i0, template: "<!-- Topbar button to open the currency overlay -->\r\n<button\r\n  pButton\r\n  type=\"button\"\r\n  class=\"p-button-text p-button-rounded p-button-icon-only layout-topbar-button shadow-sm\"\r\n  (click)=\"currencyOverlay.toggle($event)\">\r\n  <i class=\"pi pi-wallet\"></i>\r\n</button>\r\n\r\n<!-- Currency overlay -->\r\n<p-overlayPanel\r\n  #currencyOverlay\r\n  appendTo=\"body\"\r\n  [dismissable]=\"true\"\r\n  [showCloseIcon]=\"true\"\r\n  styleClass=\"settings-overlay-panel\"\r\n>\r\n  <div class=\"p-field p-col-12\">\r\n    <label for=\"currencyList\" class=\"font-semibold mb-2\">Currency</label>\r\n\r\n    <p-listbox\r\n      id=\"currencyList\"\r\n      [options]=\"currencyOptions\"\r\n      [(ngModel)]=\"selectedCurrency\"\r\n      optionLabel=\"label\"\r\n      (onChange)=\"onCurrencyChange()\"\r\n      class=\"no-border p-listbox-compact\"\r\n      [showToggleAll]=\"false\"\r\n    ></p-listbox>\r\n\r\n    <div class=\"text-center p-2 mt-2 border-round shadow\">\r\n      <strong [innerHTML]=\"currencyPreview\"></strong>\r\n    </div>\r\n\r\n  </div>\r\n  <a\r\n    class=\"align-items-center bg-primary custom-card font-bold gap-3 grid justify-content-center mt-2 p-2\"\r\n    (click)=\"onApplyCurrency(); currencyOverlay.hide(); $event.preventDefault()\"\r\n    *ngIf=\"!applyCurrencyDisabled\"\r\n  >\r\n    <i class=\"pi pi-check\"></i>\r\n    Apply\r\n  </a>\r\n</p-overlayPanel>\r\n", styles: [""], dependencies: [{ kind: "component", type: i3.OverlayPanel, selector: "p-overlayPanel", inputs: ["ariaLabel", "ariaLabelledBy", "dismissable", "showCloseIcon", "style", "styleClass", "appendTo", "autoZIndex", "ariaCloseLabel", "baseZIndex", "focusOnShow", "showTransitionOptions", "hideTransitionOptions"], outputs: ["onShow", "onHide"] }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: i5.Listbox, selector: "p-listbox", inputs: ["id", "searchMessage", "emptySelectionMessage", "selectionMessage", "autoOptionFocus", "ariaLabel", "selectOnFocus", "searchLocale", "focusOnHover", "filterMessage", "filterFields", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "scrollHeight", "tabindex", "multiple", "style", "styleClass", "listStyle", "listStyleClass", "readonly", "disabled", "checkbox", "filter", "filterBy", "filterMatchMode", "filterLocale", "metaKeySelection", "dataKey", "showToggleAll", "optionLabel", "optionValue", "optionGroupChildren", "optionGroupLabel", "optionDisabled", "ariaFilterLabel", "filterPlaceHolder", "emptyFilterMessage", "emptyMessage", "group", "options", "filterValue", "selectAll"], outputs: ["onChange", "onClick", "onDblClick", "onFilter", "onFocus", "onBlur", "onSelectAllChange"] }, { kind: "directive", type: i6.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i7.ButtonDirective, selector: "[pButton]", inputs: ["iconPos", "loadingIcon", "label", "icon", "loading", "severity", "raised", "rounded", "text", "outlined", "size", "plain"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CurrencyComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-currency', standalone: false, template: "<!-- Topbar button to open the currency overlay -->\r\n<button\r\n  pButton\r\n  type=\"button\"\r\n  class=\"p-button-text p-button-rounded p-button-icon-only layout-topbar-button shadow-sm\"\r\n  (click)=\"currencyOverlay.toggle($event)\">\r\n  <i class=\"pi pi-wallet\"></i>\r\n</button>\r\n\r\n<!-- Currency overlay -->\r\n<p-overlayPanel\r\n  #currencyOverlay\r\n  appendTo=\"body\"\r\n  [dismissable]=\"true\"\r\n  [showCloseIcon]=\"true\"\r\n  styleClass=\"settings-overlay-panel\"\r\n>\r\n  <div class=\"p-field p-col-12\">\r\n    <label for=\"currencyList\" class=\"font-semibold mb-2\">Currency</label>\r\n\r\n    <p-listbox\r\n      id=\"currencyList\"\r\n      [options]=\"currencyOptions\"\r\n      [(ngModel)]=\"selectedCurrency\"\r\n      optionLabel=\"label\"\r\n      (onChange)=\"onCurrencyChange()\"\r\n      class=\"no-border p-listbox-compact\"\r\n      [showToggleAll]=\"false\"\r\n    ></p-listbox>\r\n\r\n    <div class=\"text-center p-2 mt-2 border-round shadow\">\r\n      <strong [innerHTML]=\"currencyPreview\"></strong>\r\n    </div>\r\n\r\n  </div>\r\n  <a\r\n    class=\"align-items-center bg-primary custom-card font-bold gap-3 grid justify-content-center mt-2 p-2\"\r\n    (click)=\"onApplyCurrency(); currencyOverlay.hide(); $event.preventDefault()\"\r\n    *ngIf=\"!applyCurrencyDisabled\"\r\n  >\r\n    <i class=\"pi pi-check\"></i>\r\n    Apply\r\n  </a>\r\n</p-overlayPanel>\r\n" }]
        }], ctorParameters: () => [{ type: CurrencyService }, { type: i2.Router }] });

// projects/currency/src/lib/currency/currency.module.ts
class CurrencyModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CurrencyModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.3", ngImport: i0, type: CurrencyModule, declarations: [CurrencyComponent], imports: [OverlayPanelModule, FormsModule, ListboxModule, CommonModule, ButtonModule], exports: [CurrencyComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CurrencyModule, imports: [OverlayPanelModule, FormsModule, ListboxModule, CommonModule, ButtonModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.3", ngImport: i0, type: CurrencyModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [CurrencyComponent],
                    imports: [OverlayPanelModule, FormsModule, ListboxModule, CommonModule, ButtonModule],
                    exports: [CurrencyComponent]
                }]
        }] });

/*
 * Public API Surface of currency
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CurrencyCellRendererComponent, CurrencyComponent, CurrencyModule, CurrencyService };
//# sourceMappingURL=ag-grid-currency-formatter.mjs.map
