import * as i0 from '@angular/core';
import { ChangeDetectorRef, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { Router } from '@angular/router';
import * as i2 from 'primeng/overlaypanel';
import * as i3 from '@angular/forms';
import * as i4 from 'primeng/listbox';
import * as i5 from '@angular/common';
import * as i6 from 'primeng/button';

interface CurrencyOption {
    code: string | null;
    locale: string | null;
    label: string;
}
declare class CurrencyService {
    private readonly CURR_CODE_KEY;
    private readonly CURR_LOCALE_KEY;
    private readonly NONE;
    readonly currencies: CurrencyOption[];
    private _currency;
    getCurrency(): CurrencyOption;
    getCurrencyCode(): string | null;
    getCurrencyLocale(): string | null;
    isNone(): boolean;
    /** Accepts a CurrencyOption, a code string, or null to clear. */
    setCurrency(opt: CurrencyOption | string | null): void;
    private readCurrencyFromLS;
    private removeFromLS;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrencyService>;
}

declare class CurrencyCellRendererComponent implements ICellRendererAngularComp {
    private cdr;
    private params;
    private value;
    html: string;
    private code;
    private locale;
    private minFrac;
    private maxFrac;
    private useGrouping;
    constructor(cdr: ChangeDetectorRef);
    agInit(params: any): void;
    refresh(params: any): boolean;
    onStorageChanged(ev: StorageEvent): void;
    onCurrencyEvent(): void;
    private render;
    private resolveOptions;
    private readCodeFromLS;
    private readLocaleFromLS;
    private pickNum;
    private invalidate;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyCellRendererComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CurrencyCellRendererComponent, "app-currency-cell", never, {}, {}, never, never, true, never>;
}

declare class CurrencyComponent implements OnInit {
    settings: CurrencyService;
    private router;
    currencyOptions: CurrencyOption[];
    selectedCurrency: CurrencyOption;
    /** bind with [innerHTML] in the template */
    currencyPreview: string;
    applyCurrencyDisabled: boolean;
    constructor(settings: CurrencyService, router: Router);
    ngOnInit(): void;
    onCurrencyChange(): void;
    onApplyCurrency(): void;
    private updateCurrencyPreview;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CurrencyComponent, "app-currency", never, {}, {}, never, never, false, never>;
}

declare class CurrencyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CurrencyModule, [typeof CurrencyComponent], [typeof i2.OverlayPanelModule, typeof i3.FormsModule, typeof i4.ListboxModule, typeof i5.CommonModule, typeof i6.ButtonModule], [typeof CurrencyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CurrencyModule>;
}

export { CurrencyCellRendererComponent, CurrencyComponent, CurrencyModule, CurrencyService };
export type { CurrencyOption };
